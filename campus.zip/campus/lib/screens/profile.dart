import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black,), 
          onPressed: (){
            Navigator.pop(context);
          }),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.unfold_more), 
            onPressed: null)
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Container(
              margin: EdgeInsets.only(left: 10, right: 10),
              height: 280,
              width: 420,
              // decoration: BoxDecoration(
              //   boxShadow: [
              //       BoxShadow(
              //         spreadRadius: 0.0,
              //         color: Colors.grey,
              //         offset: Offset(1.0, 0.75),
              //         blurRadius: 1.0
              //       )
              //     ],
              //   color: Colors.white,
              //   borderRadius: BorderRadius.only(
              //     bottomLeft: Radius.circular(15),
              //     bottomRight: Radius.circular(15)
              //   )
              // ),
              child: Card(
                elevation: 5,
                              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    // Padding(
                    //   padding: const EdgeInsets.only(left:8.0),
                    //   child: Text('My Profile', 
                    //     style: TextStyle(
                    //       fontSize: 25,
                    //       fontWeight: FontWeight.bold,
                    //       fontFamily: 'WorkSansSemiBold'
                    //     ),),
                    // ),
                    // SizedBox(height: 20,),
                    Padding(
                      padding: const EdgeInsets.only(left: 170, top: 5),
                      child: CircleAvatar(
                        backgroundImage: AssetImage('assets/images/arqcoaster_2x.png'),
                        radius: 30,
                        backgroundColor: Colors.transparent,
                      ),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.only(left: 145),
                      child: Text('Awa Felix',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          fontFamily: 'WorkSansBold'
                        ),),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.only(left: 110),
                      child: Text('Something relating to bio or so',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                          
                        ),),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.only(left: 145),
                      child: Text('Bio continues',
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w400,
                          fontFamily: 'WorkSansBold'
                        ),),
                    ),
                    SizedBox(height: 50),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            Text('Photos',
                             style: TextStyle(
                               fontSize: 20,
                               fontWeight: FontWeight.bold
                             ),),
                            Text('456', style: TextStyle(
                               fontSize: 20,
                               fontWeight: FontWeight.bold
                             ))
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Text('Followers', style: TextStyle(
                               fontSize: 20,
                               fontWeight: FontWeight.bold
                             )),
                            Text('456', style: TextStyle(
                               fontSize: 20,
                               fontWeight: FontWeight.bold
                             ))
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Text('Follows', style: TextStyle(
                               fontSize: 20,
                               fontWeight: FontWeight.bold
                             )),
                            Text('456', style: TextStyle(
                               fontSize: 20,
                               fontWeight: FontWeight.bold
                             ))
                          ],
                        ),
                      ],
                    )
                  ],
                ),
              ),
            ),
            SizedBox(height: 5),
            Container(
                height: 500,
                width: 390,
                color: Colors.transparent,
                child: ListView(
                  physics: BouncingScrollPhysics(),
                  children: <Widget>[
                    Container(
                      height: 380,
                      width: 350,
                      child: Card(
                        elevation: 10,
                        color: Colors.white,
                        child: Image.asset('assets/images/photo-1461280360983-bd93eaa5051b.jpeg', fit: BoxFit.cover,),
                      ),
                    ),
                    Container(
                      height: 380,
                      width: 350,
                      child: Card(
                        elevation: 10,
                        color: Colors.white,
                        child: Image.asset('assets/images/meet_online_couple_sodas_1600.jpg', fit: BoxFit.cover,),
                      ),
                    ),
                    Container(
                      height: 380,
                      width: 350,
                      child: Card(
                        elevation: 10,
                        color: Colors.white,
                        child: Image.asset('assets/images/login_logo.png', fit: BoxFit.cover,),
                      ),
                    ),
                    Container(
                      height: 380,
                      width: 350,
                      child: Card(
                        elevation: 10,
                        color: Colors.white,
                        child: Image.asset('assets/images/wpid-11.png', fit: BoxFit.cover,),
                      ),
                    ),
                  ],
                ),
              )
          ],
        ),
      ),
    );
  }
}